#define ARG0    0  /* apila 1er. argumento */
#define ARG1    1  /* apila 2do. argumento */
#define ST_ARG0 2  /* guarda 1er. argumento */
#define ST_ARG1 3  /* guarda 2do. argumento */
#define JMP     4  /* salto incondicional en un cierto desplazamiento */
#define JMPEQ   5  /* salta si los 2 elem. del tope de la pila son == */
#define JMPGE   6  /* salta si el 2do. elem. es >= que el 1er. elem. */
#define RET     7  /* retorna del interprete */
#define SUB     8  /* calcula 2do. elem. - 1er. elem. y lo deja en la pila */

/* instrucciones necesarias para sieve */

#define LOCAL0  9  /* apila 1era. variable local */
#define LOCAL1  10 /* apila 2da. variable local */
#define LOCAL2  11 /* apila 3era. variable local */
#define LOCAL3  12 /* apila 4ta. variable local */
#define ST_LOCAL0 13 /* guarda 1era. variable local */
#define ST_LOCAL1 14 /* guarda 2da. variable local */
#define ST_LOCAL2 15 /* guarda 3era. variable local */
#define ST_LOCAL3 16 /* guarda 4ta. variable local */

#define ARRAY     17 /* apila un elemento de un arreglo */
                     /* el indice lo obtiene de la pila */
#define ST_ARRAY  18 /* guarda un elemento de un arreglo */
                     /* El valor y el indice lo obtiene de la pila */

#define ADD     19 /* calcula 2do. elem. + 1er. elem. y lo deja en la pila */

#define JMPNE   20 /* salta si los 2 elem. del tope de la pila son != */
#define JMPGT   21 /* salta si el 2do. elem. es > que el 1er. elem. */

#define PUSH    22 /* apila una constante */
