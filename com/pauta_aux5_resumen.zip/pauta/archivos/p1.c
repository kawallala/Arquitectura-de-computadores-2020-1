int n = 10;

int start(){
	int a = n; // %ebx
	if(a<=1){
		return 1; // RETURN1
	}
	int b = 1; // % eax
	while(a != 0){ // ciclo
		b = b*a;
		a--;
	}		
	return b; //RETURN
}