
int p( int x, int a[], int n){
	int j = n-1; // j -> %ecx
	int i = 0;   // i -> %ebx 

	do{ // L2
		unsigned int k = i+j; // k -> eax
		k /= 2;
		int v = a[k]; // v -> %edx
		if(x == v){ // x == a[k]
			// .L5
			return 	k;
		}
		else if(x < v){ // x < a[k]
			// .L6
			j = k-1; 
		}
		else{
			i = k+1;
		}
	}while(i<=j); // Jump L2
	return -1;
}